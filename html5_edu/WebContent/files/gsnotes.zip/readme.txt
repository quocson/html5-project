GoldenSection Notes
Copyright (C) 1999-2001 TGSLABS Ltd.
Version 1.30 (Build 127)
Freeware

GoldenSection Notes is a compact and easy-to-use notebook designed for
storing various textual and graphical information in a serviceable and
clear tree-structured form.

By means of WordPad-like rich-text, you can perform main
text-formatting functions: changing font size and style,
highlighting, underlining, using italics, bold typing, margins,
marked lists, etc. Created documents can be moved to any other section
of the program.

GS Notes is ideal for storing practically any kind of information -
notes, recipes, quotes, Web locations, pictures and even entire
Web-pages. Now you don't have to create a number of text files
scattered on the hard disk and rummage in them for hours while
searching for some necessary notes. It takes you no more than a second
to get to your info and notes with this comprehensible and easily
adjustable Windows Explorer-like interface of the program. The program
enables you to use search and print functions; it can be also be
integrated with your favorite e-mail program and Web-browser.

For your comfort we provided the possibility for starting the program
as a convenient icon in the System Tray area of the Windows taskbar.

GoldenSection Notes also supports multiple languages. Currently,
English, German, French, Russian, Polish, Portuguese-br, Slovak, and
Greek language files are available.

Compact executable file, quick search and user-friendly interface help
you to manage your personal data at lightning speed.


Contribute your own data files
------------------------------
It can be any reference or knowledge base that you want to share with
others. If you are the author of such .gso file, if this file contains
more than 100 records, if we find it interesting, we will publish it
here and will send you a free GoldenSection Organizer registration to
you.


Main features of GoldenSection Notes are:
-----------------------------------------

Interface

  - Easy-to-use 
  - Complete multi-lingual interface
     (English, German, French, Russian, Polish, Portuguese-br, Slovak, Greek) 
  - Convenient visual tree outline form 
  - Unlimited number of project files and enclosed documents 
  - Minimizes to system tray 
  - Minimizes on close 
  - Customized toolbars 
  - Customized message dialogs 
  - User-defined fonts and documents background 
  - Auto save settings and form position 
  - Printing 
  - Year 2000 compliant 
  - Install & uninstall

Notes

  - Rich Text Format (RTF) 
  - Find/Replace 
  - Paragraph formatting 
  - Insert pictures into text 
  - URL auto-detecting

and more to explore and use....


Our other products:
-------------------

GoldenSection Organizer

GoldenSection Organizer is a full-scale personal information manager
(PIM), designed to help you in organizing, tracking and planning your
business and private life. It is a planner, notebook and address book
all in one.

Computer version of the organizer comprises all features of its paper
prototype in a more comfortable way, that makes working with it
quicker and easier. Its intuitive interface combines all your notes,
bookmark lists, holidays, reminders, appointments, task lists, and
contacts into a coherent tree outline form, that can be customized
according to your requirements. You don't have to leaf through the
address book searching for the necessary name anymore, all planned
jobs can get different priorities, and you can trace how much of the
job you have completed. Now you will never miss holidays or birthdays;
you will be notified about upcoming appointments, meetings and jobs,
and, moreover, you will be able to track your everyday tasks.

In addition, Notes area (equipped with WordPad-like rich-text tools)
is perfectly suitable for keeping various information like notes,
recipes, quotations, Web addresses, pictures and even entire Internet
pages.

Application features include versatile data sorting and filtering,
printing, automatic dialing of phone numbers, integration with your
e-mail client and Web browser. All traditional holidays are taken into
account in the application distribution and you can also add your own
dates.

For your comfort we made it possible to run the program as a
convenient icon in the System Tray area of the Windows taskbar. It can
also be integrated with Chameleon Clock by Softshape Development.

GoldenSection Organizer also supports multiple languages. Currently,
English, German, French, Russian, Polish, Portuguese-br, Slovak, and
Greek language files are available.

We have teamed with Softshape Development in order to offer you most
powerful solutions for managing your personal information at
discounted price.

Remember all your important information with this fast, small, and
easy-to-use program...

Contribute your own data files
It can be any reference or knowledge base that you want to share with
others. If you are the author of such .gso file, if this file contains
more than 100 records, if we find it interesting, we will publish it
here and will send you a free GoldenSection Organizer registration to
you.



Enjoy GoldenSection Notes!

http://www.tgslabs.com
mailto:support@tgslabs.com
